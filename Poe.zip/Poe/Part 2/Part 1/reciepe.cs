﻿using System.Diagnostics.Metrics;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using System.Collections;

namespace Part_1
{
    internal class reciepe
    {
        static int numIng = 0; //The varieble for the sizes of the arrays which is number of ingredients.
        static int numSteps = 0; //The varieble to set the array of description which is number of steps.
        static int numRec = 0;
        double totCal = 0;
        int resetResponse; // The variable for the respose from the user if the arrays should reset 
        Dictionary<string,int> myDictionary;
       SortedList RecName;
        ArrayList ingrediants;
       List<double> quantity;
        List<string> measurement;
        List<string> stepDescription;
        List<string> food;
        List<double> calories;

        public reciepe() // In the constructor all arrays are initialised and all the methods are called
        {
            do
            {
                Console.WriteLine("How many recipe's would you like to enter");
                numRec = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter number of ingredients ");
                numIng = Convert.ToInt32(Console.ReadLine());
                ingrediants = new ArrayList();
                quantity = new List<double>();
                measurement = new List<string>();
                stepDescription = new List<string>();
                myDictionary = new Dictionary<string, int>();
                RecName = new SortedList();
               food=new List<string>();
               calories=new List<double>();

                
                populate(ref ingrediants, quantity, measurement, stepDescription, RecName, food, calories);
                print(ingrediants, quantity, measurement, stepDescription, RecName);
               scale(quantity);
                search(RecName, ingrediants, quantity, measurement, stepDescription, food, calories);
                reset(ingrediants, quantity, measurement, stepDescription);

            } while (resetResponse == 1);

        }
        public void populate(ref ArrayList ingrediants, List<double> quantity, List<string> measurement, List<string> stepDescription, SortedList RecName, List<string> food, List<double> calories)
        //This method is to set all values of the list
        {
            Console.WriteLine("Welcome to the first recipe");
            for (int f = 0; f < numRec; f++)
            {
                Console.WriteLine("Enter recipe " + (f + 1) + " name");
                RecName.Add(Console.ReadLine(),f);
                

               for (int i = 0; i < numIng; i++)
                {
                   try
                  {


                       Console.WriteLine("Enter name of ingredient " + (i + 1));
                        ingrediants.Add(Console.ReadLine());


                        Console.WriteLine("Enter quantity of ingredient " + (i + 1));
                        quantity.Add(Convert.ToInt32(Console.ReadLine()));

                        Console.WriteLine("Enter ingredient measurement of " + (i + 1));
                        measurement.Add(Console.ReadLine());

                        Console.WriteLine("Enter food group of ingredient " + (i + 1));
                        food.Add(Console.ReadLine());

                        Console.WriteLine("Enter number of calories " + (i + 1));
                        calories.Add(Convert.ToInt32(Console.ReadLine()));

                    Console.WriteLine("Enter number of steps");
                        numSteps = Convert.ToInt32(Console.ReadLine());


                        for (int j = 0; j < numSteps; j++)
                        {
                            Console.WriteLine("Enter step " + j + " description");
                            stepDescription.Add(Console.ReadLine());
                        }

                    }
                   catch (Exception e)
                    {

                    }
              

                }
            }
        }
       

        public void print(ArrayList ingrediants, List<double> quantity, List<string> measurement, List<string> stepDescription, SortedList RecName)
        //This method prints out all of the arrays and displays
        {

           // try
            //{
            for (int f = 0; f < numRec; f++)
            {
                    int order = (int)RecName.GetByIndex(f);
                    Console.WriteLine("*************************");
                    Console.WriteLine("For recipe " + (f + 1));
                    Console.WriteLine(RecName.GetKey(f));
                    Console.WriteLine("Array num " + order);
                totCal = 0;


                for (int i = 0; i < numIng; i++)
                {
                    Console.WriteLine("For recipe " + (f + 1));
                    Console.WriteLine(RecName.GetKey(f));
                    Console.WriteLine("*************************");


                    try
                    {
                        Console.WriteLine("Array num " + order);
                        Console.WriteLine("Ingrediant " + (i + 1) + " is " + ingrediants[order]);
                    }
                    catch (Exception e) { }
                    Console.WriteLine("The quantity for " + ingrediants[order] + " is " + quantity[order]);
                    Console.WriteLine("The unit of measurement for " + ingrediants[order] + " is " + measurement[order]);
                    for (int j = 0; j < stepDescription.Count; j++) { Console.WriteLine("Steps of recipe :" + stepDescription[j]); }
                   
                    order++;
                  
                  
                 
                         totCal = totCal+ calories[i + (numIng* f)];
                    
                    Console.WriteLine("*************************");
                }

                Console.WriteLine("The total calories is: " + totCal);
                if (totCal > 300)
                {
                    Console.WriteLine("The calories exeed 300 calories");
                }

            }



           // }
           // catch (Exception e) { }
        }

            public void scale(List<double> quantity) // This method is for the user to change the scale of the quantity of the ingredients 
        {
            Console.WriteLine("Would you like to (1)double or (2)half or (3)triple your scale");
            int scaleResult = Convert.ToInt32(Console.ReadLine());
            switch (scaleResult)
            {
                case 1:
                    for (int i = 0; i < numIng; i++)
                    {
                        quantity[i] = Convert.ToInt32(quantity[i]) * 2;
                    }
                    break;
                case 2:
                    for (int i = 0; i < numIng; i++)
                    {
                        quantity[i] = Convert.ToInt32(quantity[i]) / 2;
                    }
                    break;
                case 3:
                    for (int i = 0; i < numIng; i++)
                    {
                        quantity[i] = Convert.ToInt32(quantity[i]) * 3;
                    }
                    break;
                default:
                    Console.WriteLine("Invalid entry");
                    break;



            }
            Console.WriteLine("Would you like to reset your scale (1)yes (2)no");
            int reset = Convert.ToInt32(Console.ReadLine());
            if (reset == 1)
            {
                switch (scaleResult)
                {
                    case 1:
                        for (int i = 0; i < numIng; i++)
                        {
                            quantity[i] = Convert.ToInt32(quantity[i]) / 2;
                        }
                        break;
                    case 2:
                        for (int i = 0; i < numIng; i++)
                        {
                            quantity[i] = Convert.ToInt32(quantity[i]) * 2;
                        }
                        break;
                    case 3:
                        for (int i = 0; i < numIng; i++)
                        {
                            quantity[i] = Convert.ToInt32(quantity[i]) / 3;
                        }   
                        break;
                    default:
                        Console.WriteLine("Invalid entry");
                        break;



                }

            }
           print( ingrediants, quantity, measurement, stepDescription,RecName);
        }
        public void search(SortedList RecName, ArrayList ingrediants, List<double> quantity, List<string> measurement, List<string> stepDescription, List<string> food, List<double> calories) {
            Console.WriteLine("Enter a recipe to display");
            string search=Console.ReadLine();
            for (int i=0; i<RecName.Count; i++) {
                if (search == (string)RecName.GetKey(i)) {
                    int order = (int)RecName.GetByIndex(i);
                    Console.WriteLine("For recipe " + (i + 1));
                    Console.WriteLine(RecName.GetKey(i));
                    Console.WriteLine("*************************");


                    try
                    {
                        Console.WriteLine("Array num " + order);
                        Console.WriteLine("Ingrediant " + (i + 1) + " is " + ingrediants[order]);
                    }
                    catch (Exception e) { }
                    Console.WriteLine("The quantity for " + ingrediants[order] + " is " + quantity[order]);
                    Console.WriteLine("The unit of measurement for " + ingrediants[order] + " is " + measurement[order]);
                    for (int j = 0; j < stepDescription.Count; j++) { Console.WriteLine("Steps of recipe :" + stepDescription[j]); }
                    Console.WriteLine("*************************");
                }
            }

        }

        public void reset(ArrayList ingrediants, List<double> quantity, List<string> measurement, List<string> stepDescription)
        //This method asks the user if they would like to reset all arrays to make a new recipe
        {
            Console.WriteLine("Would you like to reset recipe (1)yes or (2)no");
            resetResponse = Convert.ToInt32(Console.ReadLine());
            if (resetResponse == 1)
            {
                ingrediants.Clear();
                quantity.Clear();
                measurement.Clear();
                stepDescription.Clear();


            }
           
        }
    }
}
    

