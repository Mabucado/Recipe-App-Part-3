﻿using System.Diagnostics.Metrics;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;

namespace Part_1
{
    internal class reciepe
    {
        static int  numIng = 0; //The varieble for the sizes of the arrays which is number of ingredients.
      static  int numSteps = 0; //The varieble to set the array of description which is number of steps.
        int resetResponse; // The variable for the respose from the user if the arrays should reset 
        string[] ingrediants; 
        double[] quantity;
        string[] measurement;
        string[] stepDescription;

        public reciepe() // In the constructor all arrays are initialised and all the methods are called
        {
            do
            {
                Console.WriteLine("Enter number of ingredients ");
                numIng = Convert.ToInt32(Console.ReadLine());
                ingrediants = new string[numIng];
                quantity = new double[numIng];
                measurement = new string[numIng];
                stepDescription = new string[numIng];



                populate(ref ingrediants, quantity, measurement, stepDescription);
                print( ingrediants, quantity,  measurement,  stepDescription);
                scale(quantity);
                reset(ingrediants, quantity, measurement, stepDescription);
            } while (resetResponse == 1);

        }
        public  void populate(ref string[] ingrediants, double[] quantity, string[] measurement, string[] stepDescription)
            //This method is to set all values of the arrays 
        {
            Console.WriteLine("Welcome to the first recipe");
           
            for (int i = 0; i < numIng; i++)
            {
                try
                {
                    Console.WriteLine("hello");
                  
                    Console.WriteLine("Enter name of ingredient " + (i + 1));
                    ingrediants[i] = Console.ReadLine();


                    Console.WriteLine("Enter quantity of ingredient " + (i + 1));
                    quantity[i] = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter ingredient measurement of " + (i + 1));
                    measurement[i] = Console.ReadLine();
                    Console.WriteLine("Enter number of steps");
                    numSteps = Convert.ToInt32(Console.ReadLine());


                    for (int j = 0; j < numSteps; j++)
                    {
                    Console.WriteLine("Enter step " + j + " description");
                    stepDescription[j] = Console.ReadLine();
                    }


                }
                catch (Exception e) {
                    
                }
              
                   
            }
        }
        public void print(string[] ingrediants, double[] quantity, string[] measurement, string[] stepDescription)
            //This method prints out all of the arrays and displays
        {
            try
            {
                for (int i = 0; i < numIng; i++)
                {
                    Console.WriteLine("*************************");
                    Console.WriteLine("For recipe " + (i + 1));
                    try
                    {
                        Console.WriteLine("Ingrediant " + (i + 1) + " is " + ingrediants[i]);
                    }catch(Exception e) { }
                    Console.WriteLine("The quantity for " + ingrediants[i] + " is " + quantity[i]);
                    Console.WriteLine("The unit of measurement for " + ingrediants[i] + " is " + measurement[i]);
                    for (int j = 0; j < numSteps; j++) { Console.WriteLine("Steps of recipe :" + stepDescription[j]); }
                    Console.WriteLine("*************************");
                }


            }
            catch (Exception e) { }
        }
            public void scale(double[] quantity) // This method is for the user to change the scale of the quantity of the ingredients 
         {
            Console.WriteLine("Would you like to (1)double or (2)half or (3)triple your scale");
            int scaleResult=Convert.ToInt32(Console.ReadLine());
            switch(scaleResult)
            {
                case 1:
                    for(int i = 0;i < numIng;i++)
                    {
                        quantity[i] = quantity[i] * 2;
                    }
                break;
                case 2:
                    for (int i = 0; i < numIng; i++)
                    {
                        quantity[i] = quantity[i] / 2;
                    }
                break;
                case 3:
                    for (int i = 0; i < numIng; i++)
                    {
                        quantity[i] = quantity[i] * 3;
                    }
                break;
                    default: Console.WriteLine("Invalid entry");
                    break;



            }
            Console.WriteLine("Would you like to reset your scale (1)yes (2)no");
            int reset=Convert.ToInt32(Console.ReadLine());
            if (reset == 1)
            {
                switch (scaleResult)
                {
                    case 1:
                        for (int i = 0; i < numIng; i++)
                        {
                            quantity[i] = quantity[i] / 2;
                        }
                        break;
                    case 2:
                        for (int i = 0; i < numIng; i++)
                        {
                            quantity[i] = quantity[i] * 2;
                        }
                        break;
                    case 3:
                        for (int i = 0; i < numIng; i++)
                        {
                            quantity[i] = quantity[i] / 3;
                        }
                        break;
                    default:
                        Console.WriteLine("Invalid entry");
                        break;



                }

            }
            print( ingrediants, quantity, measurement, stepDescription);
        }
        public void reset (string[] ingrediants, double[] quantity, string[] measurement, string[] stepDescription)
            //This method asks the user if they would like to reset all arrays to make a new recipe
        {
            Console.WriteLine("Would you like to reset recipe (1)yes or (2)no");
             resetResponse =Convert.ToInt32(Console.ReadLine());
            if (resetResponse == 1)
            {
               Array.Clear( ingrediants,0, ingrediants.Length);
                Array.Clear(quantity, 0, quantity.Length);
                Array.Clear(measurement, 0, measurement.Length);
                Array.Clear(stepDescription, 0, stepDescription.Length);

            }
            print(ingrediants, quantity, measurement, stepDescription);
        }
    }
    
}
