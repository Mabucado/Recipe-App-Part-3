﻿namespace Part_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new reciepe();//The object that calls the next class with the code.
        }
    }
}
    
    
